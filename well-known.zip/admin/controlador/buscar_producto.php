<?php

require_once("conexion.php");

// strip tags may not be the best method for your project to apply extra layer of security but fits needs for this tutorial 
$search = strip_tags(trim($_POST['id_producto']));

// Do Prepared Query
$query = mysqli_query($cn, "SELECT * FROM datos WHERE sku_pac  = '$search'");
echo mysqli_error($cn);
if ($query) {
    while ($list = mysqli_fetch_assoc($query)) {
        $cupon_estructura = array(
            'sku_pac' => $list['sku_pac'],
            'nombre_pa' => $list['nombre_pa'],
            'apellido_pa' => $list['apellido_pa'],
            'edad_pa' => $list['edad_pa'],
            'sexo_pa' => $list['sexo_pa'],
            'dni_pa' => $list['dni_pa'],
            'fecha_nac_pa' => $list['fecha_nac_pa'],
            'lugar_nac_pa' => $list['lugar_nac_pa'],
            'direccion_pa' => $list['direccion_pa'],
            'distrito_pa' => $list['distrito_pa'],
            'telefono_pa' => $list['telefono_pa'],
            'profesion_pa' => $list['profesion_pa'],
            'estado_civil_pa' => $list['estado_civil_pa'],
            'correo_pa' => $list['correo_pa']
        );
        echo json_encode($cupon_estructura);
    }
} else {
    echo $cn->error;
}
