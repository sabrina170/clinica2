</div>
<div class="trend-loader">
    <div class="message-loader">
        <img src="assets/img/loader.png" class="img-loader">
    <p >Cargando...</p>
    </div>
    
</div>
</body>
<script>
   $(document).ready(function() {});
    $('.link').on('click', function(e){
        $('.trend-loader').fadeIn();
        
    });
</script>
</html>